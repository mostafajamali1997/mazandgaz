<?php
//$this->form_validation->set_message('captcha', 'Error Message');
$lang['captcha_callable'] = 'Please Enter captcha correctly';