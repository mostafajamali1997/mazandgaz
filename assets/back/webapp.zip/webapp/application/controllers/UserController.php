<?php
class UserController extends MY_Controller {
    public function __construct()
    {

        parent::__construct();
        $this->load->model('UserModel');//khodesh ye object ba esm UserModel misaze
    }

    public function index(){

    }
    public function register(){
        if($this->doesUserLoggedInWithSessionOrCookies())//Az My Controller to folder core
            redirect('/UserController/usersPanel/');
        else
        {
            if($this->doesUserSendForms()=='requestMustBePost') // badan peyghamasho bezar
                $this->load->view('newRegisterPage');
            else
            {
                if($this->doesRegisterValidationSuccessful($this->input->post('handyCareerOptions')))

                if(strcasecmp($statusOfFunctionWork=$this->UserModel->register(),'Duplicate')==0)//age barabar bood 0 mide na 1
                {
                    $data['usernameDuplicate']='this Username that you entered is duplicate with another please enter new username ';
                    $this->load->view('newRegisterPage', $data);
                    return 0;
                }
                redirect('UserController/usersPanel');
            }
        }
        return 0;
    }
    public function login()
    {
        if ($this->doesUserLoggedInWithSessionOrCookies())//Az My Controller to folder core inja bas false bashe ama register true
            redirect('/UserController/usersPanel/');
        else {
            {
                if ($this->doesUserSendForms() == 'requestMustBePost') // badan peyghamasho bezar
                    $this->load->view('newLoginPage');
                else {
                    if ($this->doesLoginValidationSuccessful()) {
                        $statusOfFunctionWork = $this->UserModel->login();
                        if ($statusOfFunctionWork == 'usernameIsWrong' || $statusOfFunctionWork == 'passwordIsWrong') {
                            $data['userPassError'] = 'Username or password was incorrect';
                            $this->load->view('newLoginPage', $data);
                        } else if ($statusOfFunctionWork == 'isntActive') {
                            $data['userPassError'] = 'Your Account isn\'t Activate';
                            $this->load->view('newLoginPage', $data);
                        }
                    }
                }
            }
        }
    }
    private function doesLoginValidationSuccessful()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->doesCaptchaFilledCorrectly();// jaye in ba ye rule ekhtesasi $this->form_validation->set_rules('captcha','captcha','required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('newLoginPage');
            return false;
        }
        else
        {
            return true;
        }
    }
    private function doesRegisterValidationSuccessful($handyCareer)
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('repassword','Re-Password','required|matches[password]');

        $this->form_validation->set_rules('fname','FirstName','required');
        $this->form_validation->set_rules('lname','LastName','required');
        $this->form_validation->set_rules('email','email','required');
        $this->form_validation->set_rules('tel','Tel','required');
        $this->form_validation->set_rules('mobile','Mobile','required');
        $this->form_validation->set_rules('dateOfBirthday','DateOfBirthday','required');
        $this->form_validation->set_rules('nationalCode','nationalCode','required');
        $this->form_validation->set_rules('postalCode','postalCode','required');
        $this->form_validation->set_rules('sheba','sheba','required');
        $this->form_validation->set_rules('termsApproval','termsApproval','required');

        if($handyCareer=="Resellers")
        {
            $this->form_validation->set_rules('dateOfStartCooperationRes','dateOfStartCooperationRes','required');
            $this->form_validation->set_rules('dateOfEndCooperationRes','dateOfEndCooperationRes','required');
           // if($handyCareer=="Resellers")
            $this->form_validation->set_rules('resellerCode','resellerCode','required');
         //   else
               // $this->form_validation->set_rules('workingField','workingField','required');

        }
        else if($handyCareer=="serviceWorker")
        {
            $this->form_validation->set_rules('dateOfStartCooperation','dateOfStartCooperation','required');
            $this->form_validation->set_rules('dateOfEndCooperation','dateOfEndCooperation','required');
           // if($handyCareer=="Resellers")
            //    $this->form_validation->set_rules('resellerCode','resellerCode','required');
          //  else
                $this->form_validation->set_rules('workingField','workingField','required');

        }
        $this->doesCaptchaFilledCorrectly();// jaye in ba ye rule ekhtesasi $this->form_validation->set_rules('captcha','captcha','required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('newRegisterPage');
            return false;
        }
        else
        {
            return true;
        }
    }
    public function deleteUser(){
        $userModel = new UserModel();
        //TODO: check konim ke admin login shode ast
        // va permission hazf user darad ya na 
        if($userModel->deleteUser()){
            echo "user delete shod";
        }
        else{
            echo "user delete nashod ya vojod ndrd";
        }
    }

    public function getAllUsers(){
        $userModel = new UserModel();
        //TODO: check konim admin login krde bashad

        $res = $userModel->getAllUsers();
        foreach($res as $row){
            echo $row['username']." deleted=".$row['deleted_at']."\n";
        }
    }


}




