<?php


class SiteInfo extends CI_Model
{
    private $id;
    private $title;
    private $header;
    private $mobile;
    private $tel;
    private $email;
    private $telegram;
    private $instagram;
    public function __construct()
    {
        parent::__construct();
    }
    public function addSiteInfo(){
        $this->title = $this->input->post('title');
        $this->header = $this->input->post('header');
        $this->mobile = $this->input->post('mobile');
        $this->tel = $this->input->post('tel');
        $this->email = $this->input->post('email');
        $this->telegram = $this->input->post('telegram');
        $this->instagram = $this->input->post('instagram');

        $data = array(
          'title' => $this->title ,
          'header' => $this->header ,
          'mobile' => $this->mobile ,
          'tel' => $this->tel ,
          'email' => $this->email ,
          'telegram' => $this->telegram ,
          'instagram' => $this->instagram ,
        );

        $this->db->set($data);
        $this->db->insert($this->db->dbprefix . 'SiteInfo');
    }
    public function editSiteInfo(){
        $this->id = 1;
        $this->title = $this->input->post('title');
        $this->header = $this->input->post('header');
        $this->mobile = $this->input->post('mobile');
        $this->tel = $this->input->post('tel');
        $this->email = $this->input->post('email');
        $this->telegram = $this->input->post('telegram');
        $this->instagram = $this->input->post('instagram');
        $data = array(
            'title' => $this->title ,
            'header' => $this->header ,
            'mobile' => $this->mobile ,
            'tel' => $this->tel ,
            'email' => $this->email ,
            'telegram' => $this->telegram ,
            'instagram' => $this->instagram ,
        );
        $this->db->where('id', $this->id);
        $this->db->update('SiteInfo', $data);
    }
}