<div class="row">
    <div class="col">
        <h3 class="mx-auto my-auto "><?php echo $message;?></h3>

    </div>

</div>