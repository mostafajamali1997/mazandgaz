<div class="row card-columns h-50" style="font-size:14px;">
    <div class="col card mr-2" style="">
        <div class="">
            <div class="col">
                <img alt="اخبار صادو" class="img-fluid" src="https://saadco.co/img/img_mountain_dark.jpg" />
            </div>
            <div class="col-10">
                <div class="card-body">
                    <h5 class="card-title">8 متریال مطرح در صنعت ایران</h5>
                    <p class="card-text">
                        امروزه در بازار و صنعت ایران متریال های مختلفی وجود دارد که صاحبان پروژها به فراخور پروژه ها به سمت آنان جذب خواهند شد اما 8 متریال مطرح در این حوزه عبارتست از ...
                    </p>
                    <p class="card-text">
                        <small class="text-muted">آخرین بروز رسانی در سه روز پیش</small>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="col card mr-2" style="">
        <div class="">
            <div class="col">
                <img alt="اخبار صادو" class="img-fluid" src="https://saadco.co/img/img_mountain_dark.jpg" />
            </div>
            <div class="col-10">
                <div class="card-body">
                    <h5 class="card-title">8 متریال مطرح در صنعت ایران</h5>
                    <p class="card-text">
                        امروزه در بازار و صنعت ایران متریال های مختلفی وجود دارد که صاحبان پروژها به فراخور پروژه ها به سمت آنان جذب خواهند شد اما 8 متریال مطرح در این حوزه عبارتست از ...
                    </p>
                    <p class="card-text">
                        <small class="text-muted">آخرین بروز رسانی در سه روز پیش</small>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="col card" style="">
        <div class="">
            <div class="col">
                <img alt="اخبار صادو" class="img-fluid" src="https://saadco.co/img/img_mountain_dark.jpg" />
            </div>
            <div class="col-10">
                <div class="card-body">
                    <h5 class="card-title">8 متریال مطرح در صنعت ایران</h5>
                    <p class="card-text">
                        امروزه در بازار و صنعت ایران متریال های مختلفی وجود دارد که صاحبان پروژها به فراخور پروژه ها به سمت آنان جذب خواهند شد اما 8 متریال مطرح در این حوزه عبارتست از ...
                    </p>
                    <p class="card-text">

                        <small class="text-muted">آخرین بروز رسانی در سه روز پیش</small>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12 flex-column font-weight-bolder" id="hoonamFooter" style="font-size:13px;">
        <div class="row">
            <div class="col-sm-4 text-white">
                <h5 class="mt-2">پنل کاربری</h5>
                <h6>برای ورود سریع ، اطلاعات خود را وارد کنید</h6>
                <form class="form-group">
                    <label for="yourUsername">نام کاربری</label>
                    <input class="form-control" id="yourUsername" type="text" />
                    <label for="yourPassword">گذرواژه </label>
                    <input class="form-control" id="yourPassword" type="password" />
                    <button class="btn btn-md btn-success mt-2 w-50 mr-auto">
                        ورود
                    </button>
                </form>
                <h6 class="mt-2">خبرنامه</h6>
                <h6>
                    جهت دریافت بروزترین خبرها و جدیدترین تخفیف ها و آفرهاایمیل خود را در کادر زیر ثبت کنید
                </h6>
                <form class="form-group">
                    <label for="yourEmail">ایمیلتون</label>
                    <input class="form-control" id="yourEmail" type="text" />
                    <button class="btn btn-md btn-success mt-2 w-50 mr-auto">
                        منو تو خبرنامه عضو کن
                    </button>
                </form>

                <i id="goUpBtn">
                    <i class="material-icons md-48">
                        arrow_upward
                    </i>
                </i>

                <!-- <div class="hoonamSiteLogo"></div>
        <div class="hoonamSiteLogo"></div>
        <div class="hoonamSiteLogo"></div>
-->
            </div>
            <div class="col-sm-4 text-white">
                <h6 class="mt-2">فروش ویژه</h6>

                <h6>کلینیک ساختمانی</h6>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h6>محصول یک</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h6>محصول دو</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                    <li class="nav-item font-weight-bolder">
                        <a class="nav-link" href="#">
                            <h6>محصول یک</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                </ul>

                <h6>لوازم آشپزخانه</h6>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h6>محصول یک</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h6>محصول دو</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                </ul>
            </div>
            <div class="col-sm-4 text-white">
                <h5 class="mt-2">درباره ما</h5>
                <span class="h6">
                        گروه صادکو پس از چندین دهه فعالیت در آبادانی و توسعه كشور عزیزمان ایران، تلاش برای افتخار آفرینی یك شركت معتبر با رعایت اخلاق حرفه ای از طریق: مدیریت و اجرای پروژه های ساخت فعالیت در ارتقاء فرهنگ مشاركت و همكاری و عضویت در كنسرسیوم ها و مشاركت در پروژه های EPCF-EPC مدیریت مهندسی و تامین و تدارك پروژه ها را دنبال نموده ...
                    </span>
                <h5 class="mt-2">نشانی ما</h5>
                <h6 class="font-weight-bold">
                    مازندران ،کلانشهر ساری،میدان خزر جاده فرح آباد
                </h6>
                <h5 class="mt-2">ایمیل</h5>
                <p>info@sadco.com</p>
                <p>sales@sadco.com</p>
                <p>company@sadco.com</p>
                <h4>محصولات گازسوز</h4>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <h6>محصول یک</h6>
                        </a>
                        <p class="display-6">توضیحات توضیحات توضیحات توضیحات</p>
                    </li>
                </ul>
            </div>

        </div>
        <div class="row">



        </div>
    </div>
</div>
<div class="wrap"></div>

<h4 class="text-center w-100">
    <a class="hoonamFooterLink" href="">طراحی و برنامه نویسی وب اپلیکیشن توسط شرکت هونام هوشمند
    </a>
</h4>
</div>
</div>
<script src="https://saadco.co/bootstrapmin.js"></script>
<script src="https://saadco.co/popper.js"></script>
</body>

</html>